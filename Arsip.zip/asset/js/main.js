setInterval(work,200);

function work(){
    var range = document.getElementById('range').value;
    var main = document.getElementById('main');
    main.innerHTML='<img src="/static/asset/img/car'+range+'.jpg">';
}